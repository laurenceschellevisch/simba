# OSR-Reflection Include

## About
- This is an open source include.
- Used for macroing in Old School Runescape.
- Used with the open source IDE Simba https://github.com/MerlijnWajer/Simba
- Any questions you have can be answered at https://villavu.com/forum/forumdisplay.php?f=658

## Contributing
- Please make sure coding standards are the same as the include uses
- Pull requests for fixing of bugs or new features
- If you can't fix the bug, please open a new issue
